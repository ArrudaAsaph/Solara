from rest_framework import serializers
from energias.models import Usina


class UsinaRequest(serializers.Serializer):
    nome = serializers.CharField(max_length=100)

    potencia_kwp = serializers.DecimalField(
        max_digits=10,
        decimal_places=2
    )

    tipo_geracao = serializers.ChoiceField(
        choices=Usina.TipoGeracao.choices
    )

    tipo_usina = serializers.ChoiceField(
        choices=Usina.TipoUsina.choices
    )

    endereco_id = serializers.IntegerField()

    data_criacao = serializers.DateField()
