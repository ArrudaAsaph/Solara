from rest_framework import serializers
from energias.models import Usina
from contas.serializers import UsuarioResponse, EnderecoResponse

class UsinaResponse(serializers.ModelSerializer):
    usuario = UsuarioResponse(read_only = True )
    endereco = EnderecoResponse(read_only = True )

    class Meta:
        model = Usina
        fields = [
            'id',
            'nome',
            'potencia_kwp'
            'tipo_geracao',
            'tipo_usina',
            'ativa',
            'data_criacao'
            'endereco'
            'usuario'
        ]
