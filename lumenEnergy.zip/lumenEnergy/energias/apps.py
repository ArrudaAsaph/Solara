from django.apps import AppConfig


class EnergiasConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'energias'
