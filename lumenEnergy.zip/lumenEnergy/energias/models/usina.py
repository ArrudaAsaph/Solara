from django.db import models
from contas.models import Endereco


class Usina(models.Model):

    class TipoGeracao(models.TextChoices):
        VENDA = "VENDA", "Venda de Energia"
        AUTOCONSUMO = "AUTOCONSUMO", "Geração Própria"
        OUTRO = "OUTRO", "Outro"

    class TipoUsina(models.TextChoices):
        SOLO = "SOLO", "Solo"
        TELHADO = "TELHADO", "Telhado"
        FACHADA = "FACHADA", "Fachada"
        FLUTUANTE = "FLUTUANTE", "Flutuante"

    nome = models.CharField(max_length=100)

    potencia_kwp = models.DecimalField(
        max_digits = 10,
        decimal_places = 2,
        help_text = "Potência instalada em kWp"
    )

    tipo_geracao = models.CharField(
        max_length = 20,
        choices = TipoGeracao.choices
    )

    tipo_usina = models.CharField(
        max_length = 20,
        choices = TipoUsina.choices
    )

    endereco = models.ForeignKey(
        Endereco,
        on_delete=models.CASCADE,
        related_name="usina"
    )

    ativa = models.BooleanField(default=True)
    data_criacao = models.DateField()
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.nome} ({self.potencia_kwp} kWp)"
