from rest_framework.exceptions import ValidationError
from energias.models import Usina
from contas.models import Endereco, Pessoa
from core.services import ServiceBase


class UsinaService(ServiceBase):
    model = Usina

    @classmethod
    def before_create(cls, *, data, usuario_logado):
        endereco_id = data.pop("endereco_id")

        try:
            endereco = Endereco.objects.select_related(
                "pessoa", "pessoa__empresa"
            ).get(id=endereco_id)
            
        except Endereco.DoesNotExist:
            raise ValidationError("Endereço não encontrado")

        if endereco.pessoa.tipo_perfil != Pessoa.TipoPerfil.INVESTIDOR:
            raise ValidationError("Usina só pode ser criada para INVESTIDOR")

        if endereco.pessoa.empresa != usuario_logado.empresa_atual:
            raise ValidationError("Endereço não pertence à sua empresa")

        data["endereco"] = endereco
