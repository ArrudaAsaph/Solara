import os
import django

# =============================
# CONFIGURAÇÃO DJANGO
# =============================
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "lumenEnergy.settings")
django.setup()

from django.db import transaction
from contas.models import Usuario
from contas.models import Pessoa
from contas.models import Empresa


# =============================
# CONFIGURAÇÕES GERAIS
# =============================
SENHA_PADRAO = "teste123"


# =============================
# FUNÇÕES AUXILIARES
# =============================
def gerar_telefone(i):
    # garante telefone único
    return f"8499999{i:04d}"


def gerar_cpf(i):
    # cpf fake apenas para testes
    return f"{i:011d}"


def criar_usuario_e_pessoa(
    *,
    username,
    telefone,
    cpf,
    tipo_perfil,
    empresa
):
    usuario, criado = Usuario.objects.get_or_create(
        telefone=telefone,
        defaults={
            "username": username,
            "email": f"{username}@empresaA.com",
        }
    )

    if criado:
        usuario.set_password(SENHA_PADRAO)
        usuario.save()

    Pessoa.objects.get_or_create(
        usuario=usuario,
        defaults={
            "cpf": cpf,
            "tipo_perfil": tipo_perfil,
            "empresa": empresa,
            "ativo": True
        }
    )


# =============================
# SCRIPT PRINCIPAL
# =============================
@transaction.atomic
def executar_seed():
    print("🧹 Limpando dados antigos...")
    Pessoa.objects.all().delete()
    Empresa.objects.all().delete()
    Usuario.objects.all().delete()

    print("🏢 Criando empresa A...")
    usuario_empresa = Usuario.objects.create_user(
        username="empresaA",
        telefone="8400000000",
        password=SENHA_PADRAO
    )

    empresa = Empresa.objects.create(
        nome="Empresa A",
        cnpj="12.345.678/0001-90",
        descricao="Empresa A - ambiente de testes",
        usuario=usuario_empresa
    )

    contador = 1

    print("👥 Criando CLIENTES...")
    for i in range(1, 81):
        criar_usuario_e_pessoa(
            username=f"cliente{i}A",
            telefone=gerar_telefone(contador),
            cpf=gerar_cpf(contador),
            tipo_perfil=Pessoa.TipoPerfil.CLIENTE,
            empresa=empresa
        )
        contador += 1

    print("📊 Criando ANALISTAS...")
    for i in range(1, 9):
        criar_usuario_e_pessoa(
            username=f"analista{i}A",
            telefone=gerar_telefone(contador),
            cpf=gerar_cpf(contador),
            tipo_perfil=Pessoa.TipoPerfil.ANALISTA,
            empresa=empresa
        )
        contador += 1

    print("💰 Criando FINANCEIROS...")
    for i in range(1, 9):
        criar_usuario_e_pessoa(
            username=f"financeiro{i}A",
            telefone=gerar_telefone(contador),
            cpf=gerar_cpf(contador),
            tipo_perfil=Pessoa.TipoPerfil.FINANCEIRO,
            empresa=empresa
        )
        contador += 1

    print("👔 Criando GERENTES...")
    for i in range(1, 5):
        criar_usuario_e_pessoa(
            username=f"gerente{i}A",
            telefone=gerar_telefone(contador),
            cpf=gerar_cpf(contador),
            tipo_perfil=Pessoa.TipoPerfil.GERENTE,
            empresa=empresa
        )
        contador += 1

    print("✅ Seed finalizado com sucesso!")


# =============================
# EXECUÇÃO
# =============================
if __name__ == "__main__":
    executar_seed()
