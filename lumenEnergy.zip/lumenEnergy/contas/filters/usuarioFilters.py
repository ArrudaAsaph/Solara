import django_filters
from contas.models import Usuario


class UsuarioFilter(django_filters.FilterSet):
    id = django_filters.NumberFilter(
        field_name="id",
        lookup_expr="exact"
    )

    tipo_perfil = django_filters.CharFilter(
        field_name="pessoa__tipo_perfil",
        lookup_expr="exact"
    )

    email = django_filters.CharFilter(
        field_name="email",
        lookup_expr="icontains"
    )

    cpf = django_filters.CharFilter(
        field_name="pessoa__cpf",
        lookup_expr="icontains"
    )

    nome = django_filters.CharFilter(
        field_name="username",
        lookup_expr="icontains"
    )

    class Meta:
        model = Usuario
        fields = ["id", "tipo_perfil", "email", "cpf", "nome"]
