from django.db import models
from .empresa import Empresa
from .usuario import Usuario


class Pessoa(models.Model):

    class TipoPerfil(models.TextChoices):
        GERENTE = "GERENTE", "Gerente"
        INVESTIDOR = "INVESTIDOR", "Investidor"
        ANALISTA = "ANALISTA", "Analista"
        FINANCEIRO = "FINANCEIRO", "Financeiro"
        CLIENTE = "CLIENTE", "Cliente"

    cpf = models.CharField(
        max_length=14,
        unique=True
    )

    tipo_perfil = models.CharField(
        max_length=20,
        choices=TipoPerfil.choices
    )

    empresa = models.ForeignKey(
        Empresa,
        on_delete=models.CASCADE,
        related_name="pessoas"
    )

    usuario = models.OneToOneField(
        Usuario,
        on_delete=models.CASCADE,
        related_name="pessoa"
    )

    ativo = models.BooleanField(default=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.usuario.username} - {self.get_tipo_perfil_display()}"
