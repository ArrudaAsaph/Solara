from django.db import models
from .usuario import Usuario

class Empresa(models.Model):
    nome = models.CharField(max_length=255)
    cnpj = models.CharField(max_length=18, unique=True)
    descricao = models.CharField(max_length=500)


    ativa = models.BooleanField(default=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    usuario = models.OneToOneField(
        Usuario,
        on_delete = models.CASCADE,
        related_name = "empresa"
    )

    def __str__(self):
        return f"{self.nome} - CNPJ: {self.cnpj}"
