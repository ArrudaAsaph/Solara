from django.db import models
from django.contrib.auth.models import AbstractUser

class Usuario(AbstractUser):
    telefone = models.CharField(max_length=15, unique = True)
    
    @property
    def empresa_atual(self):
        if hasattr(self, "empresa"):
            return self.empresa
        return self.pessoa.empresa