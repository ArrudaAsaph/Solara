from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import status

from contas.services import EnderecoService
from contas.serializers import EnderecoRequest, EnderecoResponse

from autenticacao.permissions import *
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi


class EnderecoPrivateView(APIView):
    permission_classes = [
        IsAuthenticated,
        AnyPermission([IsGerente, IsEmpresa])
    ]

    @swagger_auto_schema(
        operation_description="Lista endereços de clientes e investidores da empresa do usuário logado",
        responses={
            200: EnderecoResponse(many=True),
            403: "Permissão negada"
        }
    )
    def get(self, request):
        enderecos = EnderecoService.listar(request.user)
        serializer = EnderecoResponse(enderecos, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    @swagger_auto_schema(
        operation_description="Cria um endereço para um cliente ou investidor da empresa",
        request_body=EnderecoRequest,
        responses={
            201: EnderecoResponse,
            400: "Erro de validação",
            403: "Permissão negada"
        }
    )
    def post(self, request):
        serializer = EnderecoRequest(data=request.data)
        serializer.is_valid(raise_exception=True)

        endereco = EnderecoService.criar(
            data=serializer.validated_data,
            usuario_logado=request.user
        )

        response = EnderecoResponse(endereco)
        return Response(response.data, status=status.HTTP_201_CREATED)
