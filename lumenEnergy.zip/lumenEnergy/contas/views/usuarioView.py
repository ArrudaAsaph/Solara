from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import status

from contas.serializers import UsuarioRequest, UsuarioUpdateRequest, UsuarioResponse
from contas.services import UsuarioService

from drf_yasg.utils import swagger_auto_schema


class UsuarioView(APIView):
    permission_classes = [IsAuthenticated]

    @swagger_auto_schema(
        operation_description="Dados do usuário logado",
        responses={200: UsuarioResponse}
    )
    def get(self, request):
        usuario = UsuarioService.listar_me(usuario_logado=request.user)
        serializer = UsuarioResponse(usuario)
        return Response(serializer.data)

    @swagger_auto_schema(
        operation_description="Atualizar dados do usuário logado (PUT)",
        request_body=UsuarioUpdateRequest,
        responses={200: UsuarioResponse}
    )
    def put(self, request):
        serializer = UsuarioUpdateRequest(data=request.data)
        serializer.is_valid(raise_exception=True)

        usuario = UsuarioService.atualizar_usuario(
            usuario_logado=request.user,
            data=serializer.validated_data
        )

        return Response(
            UsuarioResponse(usuario).data,
            status=status.HTTP_200_OK
        )

    @swagger_auto_schema(
        operation_description="Atualizar parcialmente dados do usuário logado (PATCH)",
        request_body=UsuarioUpdateRequest,
        responses={200: UsuarioResponse}
    )
    def patch(self, request):
        serializer = UsuarioUpdateRequest(
            data=request.data,
            partial=True
        )
        serializer.is_valid(raise_exception=True)

        usuario = UsuarioService.atualizar_usuario_parcial(
            usuario_logado=request.user,
            data=serializer.validated_data
        )

        return Response(
            UsuarioResponse(usuario).data,
            status=status.HTTP_200_OK
        )



