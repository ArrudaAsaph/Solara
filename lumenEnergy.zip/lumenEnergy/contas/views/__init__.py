from .enderecoPrivateView import EnderecoPrivateView
from .usuarioPrivateView import UsuarioView, UsuarioDetailView
