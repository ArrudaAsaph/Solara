from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
from contas.serializers import UsuarioRequest, UsuarioUpdateRequest, UsuarioResponse
from contas.services import UsuarioService
from autenticacao.permissions import AnyPermission, IsGerente, IsEmpresa
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi
from core.exceptions import AppException

class UsuarioView(APIView):
    permission_classes = [IsAuthenticated]

    def get_permissions(self):
        if self.request.method == "POST":
            return [AnyPermission([IsGerente, IsEmpresa])()]
        return super().get_permissions()

    usuario_filtros_swagger = [
        openapi.Parameter("id", openapi.IN_QUERY, "Filtrar por id de usuário", type=openapi.TYPE_INTEGER),
        openapi.Parameter("tipo_perfil", openapi.IN_QUERY, "Tipo de perfil do usuário", type=openapi.TYPE_STRING),
        openapi.Parameter("email", openapi.IN_QUERY, "Filtrar por email", type=openapi.TYPE_STRING),
        openapi.Parameter("cpf", openapi.IN_QUERY, "Filtrar por CPF", type=openapi.TYPE_STRING),
        openapi.Parameter("nome", openapi.IN_QUERY, "Filtrar por nome", type=openapi.TYPE_STRING),
    ]

    @swagger_auto_schema(
        operation_description="Listar usuários",
        manual_parameters=usuario_filtros_swagger,
        responses={200: UsuarioResponse(many=True)},
        tags=["Usuários"]
    )
    def get(self, request):
        usuarios = UsuarioService.listar(
            usuario_logado=request.user,
            tipo_perfil=request.query_params.get("tipo_perfil"),
            email=request.query_params.get("email"),
            cpf=request.query_params.get("cpf"),
            nome=request.query_params.get("nome"),
            id=request.query_params.get("id")
        )
        return Response(UsuarioResponse(usuarios, many=True).data)

    @swagger_auto_schema(
        operation_description="Criar usuário",
        request_body=UsuarioRequest,
        responses={201: UsuarioResponse},
        tags=["Usuários"]
    )
    def post(self, request):
        serializer = UsuarioRequest(data=request.data)
        serializer.is_valid(raise_exception=True)

        usuario = UsuarioService.criar(
            data=serializer.validated_data,
            usuario_logado=request.user
        )
        return Response(UsuarioResponse(usuario).data, status=status.HTTP_201_CREATED)

class UsuarioDetailView(APIView):
    permission_classes = [IsAuthenticated]

    @swagger_auto_schema(
        operation_description="Buscar usuário por ID",
        responses={200: UsuarioResponse},
        tags=["Usuários"]
    )
    def get(self, request, id):
        usuario = UsuarioService.buscar_por_id(id=id)
        return Response(UsuarioResponse(usuario).data)

    @swagger_auto_schema(
        operation_description="Atualizar usuário",
        request_body=UsuarioUpdateRequest,
        responses={200: UsuarioResponse},
        tags=["Usuários"]
    )
    def put(self, request, id):
        usuario = UsuarioService.buscar_por_id(id=id)

        serializer = UsuarioUpdateRequest(data=request.data)
        serializer.is_valid(raise_exception=True)

        usuario = UsuarioService.atualizar(
            instance=usuario,
            data=serializer.validated_data,
            usuario_logado=request.user
        )
        return Response(UsuarioResponse(usuario).data)

    @swagger_auto_schema(
        operation_description="Atualização parcial do usuário",
        request_body=UsuarioUpdateRequest,
        responses={200: UsuarioResponse},
        tags=["Usuários"]
    )
    def patch(self, request, id):
        usuario = UsuarioService.buscar_por_id(id=id)

        serializer = UsuarioUpdateRequest(data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)

        usuario = UsuarioService.atualizar(
            instance=usuario,
            data=serializer.validated_data,
            usuario_logado=request.user
        )
        return Response(UsuarioResponse(usuario).data)

    @swagger_auto_schema(
        operation_description="Remover usuário",
        responses={204: "Usuário removido"},
        tags=["Usuários"]
    )
    def delete(self, request, id):
        UsuarioService.remover(id=id, usuario_logado=request.user)
        return Response(status=status.HTTP_204_NO_CONTENT)
