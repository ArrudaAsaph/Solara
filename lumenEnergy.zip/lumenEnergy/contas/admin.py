from django.contrib import admin
from django import forms
from contas.models import Empresa
from contas.models import Usuario

class EmpresaAdminForm(forms.ModelForm):
    username = forms.CharField(label="Usuário")
    email = forms.EmailField(label="Email")
    telefone = forms.CharField(label="Telefone")

    class Meta:
        model = Empresa
        fields = ("nome", "descricao", "cnpj")



@admin.register(Empresa)
class EmpresaAdmin(admin.ModelAdmin):
    form = EmpresaAdminForm

    list_display = ("id", "nome", "cnpj", "usuario")

    def save_model(self, request, obj, form, change):
        if not change:
            senha_padrao = "Lumen@123"

            usuario = Usuario(
                username=form.cleaned_data["username"],
                email=form.cleaned_data["email"],
                telefone=form.cleaned_data["telefone"],
            )
            usuario.set_password(senha_padrao)
            usuario.save()

            obj.usuario = usuario

        super().save_model(request, obj, form, change)
