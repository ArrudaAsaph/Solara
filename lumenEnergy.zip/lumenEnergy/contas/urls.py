from django.urls import path
from contas.views import *
urlpatterns = [
    path(
            "enderecos/",
            EnderecoPrivateView.as_view(),
            name="enderecos"
        ),

    path("usuarios/", UsuarioView.as_view(), name="usuarios"),
    path("usuarios/<int:id>/", UsuarioDetailView.as_view(), name="usuarios-detail"),
]
