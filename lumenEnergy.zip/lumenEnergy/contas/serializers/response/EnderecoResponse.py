from rest_framework import serializers
from contas.models import Endereco, Pessoa
from .pessoaResponse import PessoaResponse

class EnderecoResponse(serializers.ModelSerializer):
    pessoa = PessoaResponse(read_only = True)

    class Meta:
        model = Endereco
        fields = [
            # 'id',
            'rua',
            'numero',
            'complemento',
            'bairro',
            'cep',
            'cidade',
            'estado',
            'principal',
            'pessoa'
        ]
