from rest_framework import serializers
from contas.models import Usuario
from .pessoaResponse import PessoaResponse

class UsuarioResponse(serializers.ModelSerializer):
    pessoa = PessoaResponse(read_only=True)

    class Meta:
        model = Usuario
        fields = [
            'id',
            'username',
            'email',
            'telefone',
            'first_name',
            'last_name',    
            'pessoa'  
        ]

