from rest_framework import serializers
from contas.models import Empresa

class EmpresaResponse(serializers.ModelSerializer):

    class Meta:
        model = Empresa
        fields = [
            # 'id',
            'nome',
            'descricao',
            'cnpj',
            'created_at'
        ]
