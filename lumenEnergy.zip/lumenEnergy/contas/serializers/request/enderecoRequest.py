from rest_framework import serializers

class EnderecoRequest(serializers.Serializer):
    rua = serializers.CharField(max_length=60)
    numero = serializers.CharField(max_length=20)
    complemento = serializers.CharField(
        max_length=100,
        required=False,
        allow_blank=True
    )
    bairro = serializers.CharField(max_length=60)
    cep = serializers.CharField(max_length=9)
    cidade = serializers.CharField(max_length=255)
    estado = serializers.CharField(max_length=2)  
    pessoa_id = serializers.IntegerField()
    
