from rest_framework import serializers

class EmpresaRequest(serializers.Serializer):
    nome = serializers.CharField(max_length=255)
    cnpj = serializers.CharField(max_length=18)
    descricao = serializers.CharField(max_length=255,
        required = False,
        allow_blank=True)
   

 

