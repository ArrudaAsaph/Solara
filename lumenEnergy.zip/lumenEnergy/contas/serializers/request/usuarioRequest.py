from rest_framework import serializers
from .pessoaRequest import PessoaRequest

class UsuarioRequest(serializers.Serializer):
    username = serializers.CharField(max_length=150)
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True, min_length=6)
    telefone = serializers.CharField(max_length=15)
    first_name = serializers.CharField(required=False, allow_blank=True)
    last_name = serializers.CharField(required=False, allow_blank=True)
    
    pessoa = PessoaRequest()

class UsuarioUpdateRequest(serializers.Serializer):
    username = serializers.CharField(max_length=150)
    email = serializers.EmailField()
    telefone = serializers.CharField(max_length=15)
    first_name = serializers.CharField(required=False, allow_blank=True)
    last_name = serializers.CharField(required=False, allow_blank=True)

