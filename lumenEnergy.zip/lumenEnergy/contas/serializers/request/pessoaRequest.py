from rest_framework import serializers


class PessoaRequest(serializers.Serializer):
    cpf = serializers.CharField(max_length=14)

    tipo_perfil = serializers.ChoiceField(choices=[
        "GERENTE",
        "INVESTIDOR",
        "ANALISTA",
        "FINANCEIRO",
        "CLIENTE"
    ])
