from rest_framework.exceptions import ValidationError
from contas.models import Pessoa

from core.services import ServiceBase

from core.services import ServiceBase
from core.exceptions import (
    DadoInvalido,
    RegistroJaExiste,
    PermissaoNegada,
    OperacaoNaoPermitida
)

class PessoaService(ServiceBase):
    model = Pessoa

    # Validações
    @classmethod
    def _validar_criacao(cls, *, data, usuario, empresa):
        if Pessoa.objects.filter(cpf=data["cpf"]).exists():
            raise RegistroJaExiste("CPF já cadastrado.")
        
        if hasattr(usuario, "pessoa"):
            raise OperacaoNaoPermitida("Usuário já vinculado a uma pessoa.")
        
        if not empresa:
            raise DadoInvalido("Usuário não está vinculado a nenhuma empresa")
    
    @classmethod
    def listar_por_categoria(cls, usuario_logado):
        empresa = usuario_logado.empresa_atual

        if hasattr(usuario_logado, "empresa"):
            perfis_visiveis = [
                Pessoa.TipoPerfil.GERENTE,
                Pessoa.TipoPerfil.ANALISTA,
                Pessoa.TipoPerfil.FINANCEIRO,
                Pessoa.TipoPerfil.CLIENTE,
            ]
        else:
            tipo = usuario_logado.pessoa.tipo_perfil

            PERFIS_VISIVEIS = {
                Pessoa.TipoPerfil.GERENTE: [
                    Pessoa.TipoPerfil.ANALISTA,
                    Pessoa.TipoPerfil.FINANCEIRO,
                    Pessoa.TipoPerfil.CLIENTE,
                ],
                Pessoa.TipoPerfil.ANALISTA: [
                    Pessoa.TipoPerfil.CLIENTE,
                ],
                Pessoa.TipoPerfil.FINANCEIRO: [
                    Pessoa.TipoPerfil.CLIENTE,
                ],
            }

            perfis_visiveis = PERFIS_VISIVEIS.get(tipo)

            if not perfis_visiveis:
                raise PermissaoNegada("Usuário não possui permissão para listar pessoas")

        pessoas = (
            Pessoa.objects
            .select_related("usuario")
            .filter(
                empresa=empresa,
                tipo_perfil__in=perfis_visiveis,
                ativo=True
            )
        )

        if not hasattr(usuario_logado, "empresa"):
            pessoas = pessoas.exclude(usuario=usuario_logado)

        return pessoas