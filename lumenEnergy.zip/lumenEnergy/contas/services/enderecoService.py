from rest_framework.exceptions import ValidationError
from contas.models import Endereco, Pessoa
from contas.models import Usuario
from  django.db import transaction


from core.services import ServiceBase
class EnderecoService(ServiceBase):
    model = Endereco


    @classmethod
    def _validar_criacao(cls, *, data, pessoa_id, usuario_logado):
        try:
            pessoa = Pessoa.objects.get(id = pessoa_id)
        except Pessoa.DoesNotExist:
            raise ValidationError("Pessoa não existente.")
        
        if pessoa.empresa != usuario_logado.empresa_atual:
            raise ValidationError("Pessoa não pertence à sua empresa")
        
        if pessoa.tipo_perfil not in ["CLIENTE", "INVESTIDOR"]:
            raise ValidationError(
                "Endereço permitido apenas para cliente ou investidor"
            )
        
        if Endereco.objects.filter(
            pessoa=pessoa,
            rua=data["rua"],
            numero=data["numero"],
            cep=data["cep"]
        ).exists():
            raise ValidationError("Endereço já cadastrado para esta pessoa")
        return pessoa
        
    @classmethod
    def antes_criacao(cls, *, data, pessoa_id, usuario_logado):
         return cls._validar_criacao(data = data, pessoa_id = pessoa_id, usuario_logado = usuario_logado)
        

        
    @classmethod
    @transaction.atomic
    def criar(cls, *, data, usuario_logado):
        pessoa_id = data["pessoa_id"]

        pessoa = cls.antes_criacao(data = data, pessoa_id = pessoa_id, usuario_logado = usuario_logado)
        endereco = Endereco(
            rua = data["rua"],
            numero = data["numero"],
            complemento = data.get("complemento", ""),
            cep = data["cep"],
            bairro = data["bairro"],
            cidade = data["cidade"],
            estado = data["estado"],
            pessoa = pessoa
        )

        endereco.save()

        return endereco
    
    
    @staticmethod
    def listar(gerente: Usuario):
        # Relação de Usuario --> Empresa
        try:
            empresa = gerente.empresa
        # Relação de Usuário --> Pessoa --> Empresa
        except:
            empresa = gerente.empresa_atual

        enderecos = Endereco.objects.filter(
            pessoa__empresa=gerente.empresa_atual,
            pessoa__tipo_perfil__in=["CLIENTE", "INVESTIDOR"]
        )

        return enderecos
