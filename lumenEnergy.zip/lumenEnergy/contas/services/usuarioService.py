from contas.models import Usuario, Pessoa
from  django.db import transaction
from rest_framework.exceptions import ValidationError

from contas.services import PessoaService
from core.services import ServiceBase, PermissaoService
from core.exceptions import *


class UsuarioService(ServiceBase):
    model = Usuario

    # Validações
    @classmethod
    def _validar_criacao(cls, *, data):
        if (Usuario.objects.filter(email = data["email"]).exists()):
            raise RegistroJaExiste("Email já cadastrado.")
        
        if (Usuario.objects.filter(username = data["username"]).exists()):
            raise RegistroJaExiste("Username já cadastrado.")
        
        if (Usuario.objects.filter(telefone = data["telefone"]).exists()):
                raise RegistroJaExiste("Telefone já cadastrado.")

    @staticmethod
    def _validar_uptade(usuario: Usuario, data: dict):
        if "email" in data:
            if Usuario.objects.filter(email=data["email"]).exclude(id=usuario.id).exists():
                raise RegistroJaExiste("Email já cadastrado.")

        if "username" in data:
            if Usuario.objects.filter(username=data["username"]).exclude(id=usuario.id).exists():
                raise RegistroJaExiste("Username já cadastrado.")

        if "telefone" in data:
            if Usuario.objects.filter(telefone=data["telefone"]).exclude(id=usuario.id).exists():
                raise RegistroJaExiste("Telefone já cadastrado.")

    @classmethod
    def antes_criacao(cls, *, data):
        cls._validar_criacao(data = data)

    @classmethod
    @transaction.atomic
    def criar(cls, *, data, usuario_logado):

        permissao = PermissaoService(usuario_logado)

        pessoa_data = data.pop("pessoa")
        novo_perfil = pessoa_data["tipo_perfil"]

        """
        Apenas empresas podem criar gerentes,
        E os gerentes criam todos os outros usuários, exceto outros gerentes
        """
        if novo_perfil == "GERENTE":
            permissao.acesso(["EMPRESA"])
        else:
            permissao.acesso(["EMPRESA", "GERENTE"])

        cls.antes_criacao(data=data)

        usuario = Usuario(
            username=data["username"],
            email=data["email"],
            telefone=data["telefone"],
            first_name=data["first_name"],
            last_name=data["last_name"],
        )
        usuario.set_password(data["password"])
        usuario.save()

        empresa = usuario_logado.empresa_atual

        return cls.depois_cricao(data=pessoa_data, usuario=usuario, empresa=empresa)
    

    @classmethod
    def depois_cricao(cls, *, data, usuario, empresa):
        PessoaService.criar(data = data, usuario = usuario, empresa = empresa)
        return usuario
    

    @staticmethod 
    def listar( *, 
            usuario_logado: Usuario, 
            tipo_perfil: str | None = None, 
            email: str | None = None, 
            cpf: str | None = None, 
            nome: str | None = None,
            id: int | None = None
            ): 

        pessoas = PessoaService.listar_por_categoria(usuario_logado)

        usuarios = ( Usuario.objects.select_related("pessoa").filter(pessoa__in=pessoas) ) 
        if id:
            usuarios = usuarios.filter(id__icontains=id) 
        if tipo_perfil: 
            usuarios = usuarios.filter(pessoa__tipo_perfil=tipo_perfil) 
        if email: 
            usuarios = usuarios.filter(email__icontains=email) 
        if cpf: 
            usuarios = usuarios.filter(pessoa__cpf__icontains=cpf) 
        if nome: 
            usuarios = usuarios.filter(username__icontains=nome) 

        return usuarios

    @classmethod
    def buscar_por_id(cls, *, id, usuario_logado):

        permissao = PermissaoService()
        try:
            return cls.model.objects.get(id=id)
        except cls.model.DoesNotExist:
            raise RecursoNaoEncontrado(f"Usuário com ID {id} não encontrado")
        
    @staticmethod
    def listar_me(*, usuario_logado):
        return Usuario.objects.get(id=usuario_logado.id)
    
    @classmethod
    def antes_atualizar(cls, *, instance, data):
        cls._validar_uptade(usuario = instance, data = data)


    @classmethod
    @transaction.atomic
    def atualizar(cls, *, instance, data, usuario_logado):
        cls.antes_atualizar(instance = instance, data = data)

        for campo, valor in data.items():
            setattr(instance, campo, valor)
        
        instance.save()
        return instance
    
   
    @classmethod
    @transaction.atomic
    def remover(cls, *, id, usuario_logado):
        usuario = cls.buscar_por_id(id=id)
        permissao = PermissaoService(usuario_logado)

        if PessoaService.comparar_perfil(usuario, "GERENTE"):
            permissao.acesso(["EMPRESA"])
        else:
            permissao.acesso(["EMPRESA", "GERENTE"])

        usuario.delete()



# ---------------------------------------------- EXPORT -----------------------------------------------
    @staticmethod
    def identificar_usuario( *, usuario_logado):
        try:    
            pessoa = usuario_logado.pessoa
            return PessoaService.identificar_pessoa(pessoa)
        except Usuario.pessoa.RelatedObjectDoesNotExist:
            try:
                empresa = usuario_logado.empresa
                return "EMPRESA", None
            except Usuario.empresa.RelatedObjectDoesNotExist: 
                raise ValidationError("Usuário inválido: sem vínculo com pessoa ou empresa")
            