from rest_framework.exceptions import ValidationError
from contas.models import Empresa
from contas.models import Usuario

class EmpresaService:

    @staticmethod
    def criar(data, usuario_criador: Usuario):
        if Empresa.objects.filter(cnpj=data["cnpj"]).exists():
            raise ValidationError("CNPJ já cadastrado")
        
        nova_empresa = Empresa(
            nome=data["nome"],
            descricao=data.get("descricao", ""),
            cnpj=data["cnpj"],
            usuario=usuario_criador
        )

        nova_empresa.save()
        return nova_empresa
