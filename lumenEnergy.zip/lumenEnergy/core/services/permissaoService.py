from contas.models import Pessoa, Empresa
from core.exceptions import PermissaoNegada, UsuarioInvalido

class PermissaoService:
    HIERARQUIA = ["EMPRESA", "GERENTE", "ANALISTA", "FINANCEIRO", "INVESTIDOR", "CLIENTE"]

    def __init__(self, user):
        if not user or not user.is_authenticated:
            raise UsuarioInvalido("Usuário não autenticado")
        self.user = user

    def _get_pessoa(self):
        """
        Retorna a instância Pessoa vinculada ao usuário,
        ou None se não houver.
        """
        try:
            return self.user.pessoa
        except self.user.pessoa.RelatedObjectDoesNotExist:
            return None

    def perfil_logado(self) -> str:
        """
        Retorna o perfil do usuário logado:
        - "EMPRESA" se for empresa
        - Tipo de pessoa se for pessoa
        - Lança UsuarioInvalido se não tiver perfil
        """
        if Empresa.objects.filter(usuario=self.user, ativa=True).exists():
            return "EMPRESA"

        pessoa = self._get_pessoa()
        if pessoa:
            return pessoa.tipo_perfil

        raise UsuarioInvalido("Usuário sem perfil válido")

    def _perfil_valido(self, perfil_logado: str, perfil_requerido: str) -> bool:
        """
        Checa se o perfil logado tem acesso ao perfil requerido (respeita hierarquia)
        EMPRESA sempre tem acesso a tudo
        """
        if perfil_logado == "EMPRESA":
            return True
        idx_logado = self.HIERARQUIA.index(perfil_logado)
        idx_req = self.HIERARQUIA.index(perfil_requerido)
        return idx_logado <= idx_req  

    def acesso(self, perfis: list):
        """
        Recebe uma lista de perfis e libera se o usuário logado tiver
        qualquer perfil na lista ou superior na hierarquia.
        Caso contrário, lança PermissaoNegada.
        """
        perfil = self.perfil_logado()
        for p in perfis:
            if self._perfil_valido(perfil, p):
                return True  # liberado

        raise PermissaoNegada(
            f"Usuário '{self.user.username}' não tem permissão para acessar nenhum dos perfis: {', '.join(perfis)}"
        )
