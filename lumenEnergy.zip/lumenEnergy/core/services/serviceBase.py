from django.db import transaction
from django.shortcuts import get_object_or_404


class ServiceBase:
    model = None  # obrigatório nos services filhos

    # ===== Hooks (opcionais) =====

    @classmethod
    def antes_criacao(cls, *, data, usuario_logado):
        pass

    @classmethod
    def depois_criacao(cls, *, instance, usuario_logado):
        pass

    @classmethod
    def antes_atualizar(cls, *, instance, data, usuario_logado):
        pass

    @classmethod
    def antes_remover(cls, *, instance, usuario_logado):
        pass

    # ===== CRUD =====

    @classmethod
    @transaction.atomic
    def criar(cls, *, data: dict, usuario_logado):
        if cls.model is None:
            raise RuntimeError("Service sem model definida")

        cls.antes_criacao(data=data, usuario_logado=usuario_logado)

        instance = cls.model.objects.create(**data)

        cls.depois_criacao(instance=instance, usuario_logado=usuario_logado)

        return instance

    @classmethod
    def listar(cls, *, filtros=None):
        filtros = filtros or {}
        return cls.model.objects.filter(**filtros)

    @classmethod
    def buscar_por_id(cls, *, id):
        """
        Busca um registro pelo ID ou retorna 404
        """
        return get_object_or_404(cls.model, id=id)

    @classmethod
    @transaction.atomic
    def atualizar(cls, *, instance, data: dict, usuario_logado):
        cls.antes_atualizar(
            instance=instance,
            data=data,
            usuario_logado=usuario_logado
        )

        for campo, valor in data.items():
            setattr(instance, campo, valor)

        instance.save()
        return instance

    @classmethod
    @transaction.atomic
    def remover(cls, *, instance, usuario_logado):
        cls.antes_remover(instance=instance, usuario_logado=usuario_logado)
        instance.delete()
