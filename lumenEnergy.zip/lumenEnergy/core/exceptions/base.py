import logging

logger = logging.getLogger(__name__)

class AppException(Exception):
    """
    Classe base global para todas as exceções do sistema.
    - message: mensagem do erro
    - code: código opcional do erro
    - log: automaticamente registra no logger
    """
    def __init__(self, message: str = "Ocorreu um erro no sistema", code: int = None):
        super().__init__(message)
        self.message = message
        self.code = code
        logger.error(f"[{self.__class__.__name__}] {message} | code={code}")
