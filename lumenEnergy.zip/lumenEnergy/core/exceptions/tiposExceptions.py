from .base import AppException

# Permissão / Acesso
class PermissaoNegada(AppException):
    """Usuário não tem permissão para executar a ação"""
    pass

class PerfilInvalido(AppException):
    """Perfil inválido ou não reconhecido"""
    pass

class UsuarioInvalido(AppException):
    """Usuário inválido ou não reconhecido"""
    pass

# Validação / Dados
class DadoInvalido(AppException):
    """Dados inválidos ou inconsistentes"""
    pass

class RegistroJaExiste(AppException):
    """Tentativa de criar registro duplicado"""
    pass

# Geral / Interno
class OperacaoNaoPermitida(AppException):
    """Operação não permitida no contexto atual"""
    pass

class RecursoNaoEncontrado(AppException):
    """Recurso não encontrado"""
    pass
