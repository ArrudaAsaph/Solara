from .tiposExceptions import DadoInvalido, OperacaoNaoPermitida, PerfilInvalido, PermissaoNegada, RecursoNaoEncontrado, RegistroJaExiste, UsuarioInvalido
from .handler import custom_exception_handler
from .base import AppException