from rest_framework.views import exception_handler
from rest_framework.response import Response
from core.exceptions.tiposExceptions import AppException

def custom_exception_handler(exc, context):
    """
    Captura todas as AppException e retorna Response adequada para o DRF.
    """
    # Se for uma AppException
    if isinstance(exc, AppException):
        # Defina o status code dependendo do tipo de exceção (pode refinar por classe)
        status_code = 400  # default
        if exc.__class__.__name__ in ["PermissaoNegada", "OperacaoNaoPermitida", "PerfilInvalido"]:
            status_code = 403
        elif exc.__class__.__name__ in ["RecursoNaoEncontrado"]:
            status_code = 404
        elif exc.__class__.__name__ in ["UsuarioInvalido"]:
            status_code = 401
        # Retorna a resposta DRF
        return Response(
            {
                "error": exc.__class__.__name__,
                "detail": exc.message,
                "code": exc.code
            },
            status=status_code
        )

    # Se não for AppException, cai no handler padrão do DRF
    return exception_handler(exc, context)
