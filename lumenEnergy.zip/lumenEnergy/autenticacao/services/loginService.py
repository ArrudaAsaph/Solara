from rest_framework.exceptions import AuthenticationFailed
from rest_framework_simplejwt.tokens import RefreshToken
from django.db.models import Q

from contas.models import Usuario


class LoginService:

    @staticmethod
    def login(data):
        username = data["username"]
        password = data["password"]

        usuario = Usuario.objects.filter(
            Q(username=username) | Q(email=username)
        ).first()

        if not usuario or not usuario.check_password(password):
            raise AuthenticationFailed("Usuário ou senha inválidos")

        refresh = RefreshToken.for_user(usuario)

        return {
            "access": str(refresh.access_token),
            "refresh": str(refresh),
            "usuario": {
                "id": usuario.id,
                "username": usuario.username,
                "email": usuario.email,
            }
        }
