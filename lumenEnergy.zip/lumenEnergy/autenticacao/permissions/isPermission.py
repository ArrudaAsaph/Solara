# permissions.py
from rest_framework.permissions import BasePermission

def AnyPermission(perms):
    class _AnyPermission(BasePermission):
        def has_permission(self, request, view):
            if not request.user or not request.user.is_authenticated:
                return False
            return any(perm().has_permission(request, view) for perm in perms)

        def has_object_permission(self, request, view, obj):
            return any(perm().has_object_permission(request, view, obj) for perm in perms)

    return _AnyPermission
