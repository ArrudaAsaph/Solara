from rest_framework.permissions import BasePermission
from contas.models import Pessoa, Empresa

class HasPerfil(BasePermission):
    perfis = []

    def has_permission(self, request, view):
        if not request.user or not request.user.is_authenticated:
            return False

        return Pessoa.objects.filter(
            usuario=request.user,
            tipo_perfil__in=self.perfis,
            ativo=True
        ).exists()

class IsGerente(HasPerfil):
    perfis = ["GERENTE"]

class IsAnalista(HasPerfil):
    perfis = ["ANALISTA"]

class IsFinanceiro(HasPerfil):
    perfis = ["FINANCEIRO"]

class IsInvestidor(HasPerfil):
    perfis = ["INVESTIDOR"]

class IsCliente(HasPerfil):
    perfis = ["CLIENTE"]

class IsEmpresa(BasePermission):

    def has_permission(self, request, view):
        if not request.user or not request.user.is_authenticated:
            return False

        return Empresa.objects.filter(
            usuario=request.user,
            ativa=True
        ).exists()