from .isPerfisGenericos import IsEmpresa, IsGerente, IsAnalista, IsFinanceiro, IsInvestidor, IsCliente

from .isPermission import AnyPermission